"""
predictor.py — feature engineering, training, and inference for:
  1. Win probability (classification)
  2. Against-the-spread cover probability (classification, relative to Book A's line)
  3. Total points (regression, for O/U picks)

Uses XGBoost when it's installed (pip install xgboost); otherwise falls back
to scikit-learn's HistGradientBoosting models, which use the same gradient-
boosted-tree algorithm family and need zero extra dependencies. Swap
USE_XGBOOST manually if you want to force one or the other.
"""

import os
import joblib
import numpy as np
import pandas as pd

try:
    import xgboost as xgb
    HAS_XGBOOST = True
except ImportError:
    HAS_XGBOOST = False

from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, mean_absolute_error

MODEL_DIR = os.path.join(os.path.dirname(__file__), "artifacts")
os.makedirs(MODEL_DIR, exist_ok=True)

FEATURE_COLS = [
    "home_rating", "away_rating", "rating_diff",
    "book_a_spread", "book_b_spread", "spread_diff",
    "book_a_total", "book_b_total", "total_diff",
    "is_cfb",
]


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["rating_diff"] = df["home_rating"] - df["away_rating"]
    df["spread_diff"] = df["book_a_spread"] - df["book_b_spread"]
    df["total_diff"] = df["book_a_total"] - df["book_b_total"]
    df["is_cfb"] = (df["league"] == "CFB").astype(int)
    return df


def _make_classifier():
    if HAS_XGBOOST:
        return xgb.XGBClassifier(
            n_estimators=300, max_depth=4, learning_rate=0.05,
            subsample=0.9, colsample_bytree=0.9, eval_metric="logloss",
        )
    return HistGradientBoostingClassifier(max_depth=4, learning_rate=0.05, max_iter=300)


def _make_regressor():
    if HAS_XGBOOST:
        return xgb.XGBRegressor(
            n_estimators=300, max_depth=4, learning_rate=0.05,
            subsample=0.9, colsample_bytree=0.9,
        )
    return HistGradientBoostingRegressor(max_depth=4, learning_rate=0.05, max_iter=300)


def train_all(hist_csv="data/historical_games.csv", verbose=True):
    df = pd.read_csv(hist_csv)
    df = engineer_features(df)
    X = df[FEATURE_COLS]

    results = {}
    metrics = {}

    for target, kind in [
        ("home_win", "clf"),
        ("home_covered_a", "clf"),
        ("over_a", "clf"),
    ]:
        y = df[target]
        X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=0)
        model = _make_classifier()
        model.fit(X_tr, y_tr)
        acc = accuracy_score(y_te, model.predict(X_te))
        metrics[target] = acc
        results[target] = model
        if verbose:
            print(f"[{target}] test accuracy: {acc:.3f}")

    # Regression target: actual_total (for O/U line calibration / totals prediction)
    y = df["actual_total"]
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=0)
    reg = _make_regressor()
    reg.fit(X_tr, y_tr)
    mae = mean_absolute_error(y_te, reg.predict(X_te))
    metrics["actual_total_mae"] = mae
    results["actual_total"] = reg
    if verbose:
        print(f"[actual_total] test MAE: {mae:.2f} points")
        print(f"Backend: {'XGBoost' if HAS_XGBOOST else 'scikit-learn HistGradientBoosting (XGBoost not installed)'}")

    for name, model in results.items():
        joblib.dump(model, os.path.join(MODEL_DIR, f"{name}.joblib"))
    joblib.dump(metrics, os.path.join(MODEL_DIR, "metrics.joblib"))
    return results, metrics


def load_models():
    names = ["home_win", "home_covered_a", "over_a", "actual_total"]
    return {n: joblib.load(os.path.join(MODEL_DIR, f"{n}.joblib")) for n in names}


def predict_slate(upcoming_csv="data/upcoming_games.csv", models=None):
    """Run all models on a slate of upcoming games and flag cross-book discrepancies."""
    if models is None:
        models = load_models()

    df = pd.read_csv(upcoming_csv)
    feat = engineer_features(df)
    X = feat[FEATURE_COLS]

    win_prob = models["home_win"].predict_proba(X)[:, 1]
    cover_prob = models["home_covered_a"].predict_proba(X)[:, 1]
    over_prob = models["over_a"].predict_proba(X)[:, 1]
    pred_total = models["actual_total"].predict(X)

    out = df.copy()
    out["home_win_prob"] = win_prob.round(3)
    out["away_win_prob"] = (1 - win_prob).round(3)
    out["home_cover_prob_bookA"] = cover_prob.round(3)
    out["over_prob_bookA"] = over_prob.round(3)
    out["model_predicted_total"] = pred_total.round(1)

    # Picks
    out["moneyline_pick"] = np.where(out["home_win_prob"] >= 0.5, out["home_team"], out["away_team"])
    out["ats_pick"] = np.where(
        out["home_cover_prob_bookA"] >= 0.5,
        out["home_team"] + " " + out["book_a_spread"].astype(str),
        out["away_team"] + " " + (-out["book_a_spread"]).astype(str),
    )
    out["total_pick"] = np.where(out["over_prob_bookA"] >= 0.5, "OVER " + out["book_a_total"].astype(str),
                                  "UNDER " + out["book_a_total"].astype(str))

    # --- Line-shopping / discrepancy detector -----------------------------
    # 1. Cross-book divergence: how far apart the two books' lines are.
    out["spread_book_gap"] = (out["book_a_spread"] - out["book_b_spread"]).abs()
    out["total_book_gap"] = (out["book_a_total"] - out["book_b_total"]).abs()

    # 2. Model vs. market edge: convert model win prob to an implied "fair"
    #    spread (rough NFL/CFB rule of thumb: ~1 win-prob point per ~0.03 win%),
    #    then compare against the market spread to flag value.
    #    Simple heuristic: edge = model prob - 0.5 scaled to points, minus market lean.
    out["model_implied_edge_pts"] = (out["home_win_prob"] - 0.5) * 26  # ~ logistic slope calibration
    out["ats_value_gap"] = (out["model_implied_edge_pts"] - (-out["book_a_spread"])).round(1)

    out["flag_line_discrepancy"] = (
        (out["spread_book_gap"] >= 1.0) | (out["total_book_gap"] >= 2.0)
    )
    out["flag_model_value"] = out["ats_value_gap"].abs() >= 3.0

    return out


if __name__ == "__main__":
    train_all()
    preds = predict_slate()
    cols = ["league", "home_team", "away_team", "home_win_prob", "ats_pick",
            "total_pick", "flag_line_discrepancy", "flag_model_value"]
    print(preds[cols].to_string(index=False))
