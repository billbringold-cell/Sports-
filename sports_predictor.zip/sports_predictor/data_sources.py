"""
data_sources.py

Real data pulls to swap in once you have API keys. Two free-tier-friendly
sources cover this whole project:

1. CollegeFootballData.com (CFBD) — CFB games, team ratings (SP+/ELO/FPI),
   and betting lines. Free API key: https://collegefootballdata.com
2. The Odds API — live odds across multiple sportsbooks for both NFL and
   CFB (moneyline, spreads, totals). Free tier: https://the-odds-api.com

Set env vars CFBD_API_KEY and ODDS_API_KEY, then call these functions
instead of generate_sample_data.py. Nothing here runs automatically —
this file is left as reference/scaffolding since this environment has no
outbound network access; wire it up when you run the project locally.
"""

import os
import requests
import pandas as pd

CFBD_API_KEY = os.environ.get("CFBD_API_KEY", "")
ODDS_API_KEY = os.environ.get("ODDS_API_KEY", "")

CFBD_BASE = "https://api.collegefootballdata.com"
ODDS_BASE = "https://api.the-odds-api.com/v4"


def get_cfb_games(year: int, week: int = None) -> pd.DataFrame:
    headers = {"Authorization": f"Bearer {CFBD_API_KEY}"}
    params = {"year": year}
    if week:
        params["week"] = week
    resp = requests.get(f"{CFBD_BASE}/games", headers=headers, params=params, timeout=15)
    resp.raise_for_status()
    return pd.DataFrame(resp.json())


def get_cfb_betting_lines(year: int, week: int = None) -> pd.DataFrame:
    headers = {"Authorization": f"Bearer {CFBD_API_KEY}"}
    params = {"year": year}
    if week:
        params["week"] = week
    resp = requests.get(f"{CFBD_BASE}/lines", headers=headers, params=params, timeout=15)
    resp.raise_for_status()
    return pd.DataFrame(resp.json())


def get_cfb_team_ratings(year: int) -> pd.DataFrame:
    """SP+ ratings — a strong single-number team-strength feature."""
    headers = {"Authorization": f"Bearer {CFBD_API_KEY}"}
    resp = requests.get(f"{CFBD_BASE}/ratings/sp", headers=headers, params={"year": year}, timeout=15)
    resp.raise_for_status()
    return pd.DataFrame(resp.json())


def get_odds(sport: str, regions="us", markets="h2h,spreads,totals") -> pd.DataFrame:
    """
    sport: 'americanfootball_nfl' or 'americanfootball_ncaaf'
    Returns odds from every sportsbook the API covers for each game —
    this is the raw material for the cross-book discrepancy finder.
    """
    url = f"{ODDS_BASE}/sports/{sport}/odds"
    params = {"apiKey": ODDS_API_KEY, "regions": regions, "markets": markets, "oddsFormat": "american"}
    resp = requests.get(url, params=params, timeout=15)
    resp.raise_for_status()
    return pd.DataFrame(resp.json())


def find_line_discrepancies(odds_df: pd.DataFrame, market="spreads", min_gap=1.0):
    """
    Given the-odds-api's per-game bookmaker list, flag games where sportsbooks
    disagree by more than `min_gap` points on the same market — i.e.
    candidates for +EV line shopping.
    """
    flagged = []
    for _, game in odds_df.iterrows():
        lines = []
        for book in game.get("bookmakers", []):
            for m in book.get("markets", []):
                if m["key"] != market:
                    continue
                for outcome in m["outcomes"]:
                    lines.append({
                        "book": book["title"],
                        "team": outcome["name"],
                        "point": outcome.get("point"),
                        "price": outcome.get("price"),
                    })
        if not lines:
            continue
        df = pd.DataFrame(lines)
        for team, grp in df.groupby("team"):
            if grp["point"].notna().any() and (grp["point"].max() - grp["point"].min()) >= min_gap:
                flagged.append({
                    "home_team": game.get("home_team"),
                    "away_team": game.get("away_team"),
                    "team": team,
                    "best_point": grp["point"].max(),
                    "worst_point": grp["point"].min(),
                    "gap": round(grp["point"].max() - grp["point"].min(), 1),
                })
    return pd.DataFrame(flagged)
