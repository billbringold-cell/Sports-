# Line Reader — NFL & CFB Prediction Prototype

A working prototype that predicts:
- **Moneyline** win probability
- **Against-the-spread** picks
- **Over/under** totals picks
- **Line discrepancies** — where two sportsbooks disagree, or where the model's
  view diverges meaningfully from the market, flagged as potential value bets

for **NFL** and **college football**, served as a dark, scoreboard-style
web dashboard.

## Quick start

```bash
pip install -r requirements.txt
python generate_sample_data.py   # builds a synthetic historical dataset + upcoming slate
python app.py                    # trains models on first run, then serves the site
```

Open **http://localhost:5000**.

## How it's built

| Piece | File | Notes |
|---|---|---|
| Sample/demo data | `generate_sample_data.py` | Synthetic but realistic historical games + an "upcoming" slate, since this build environment has no live network access. Swap for real data — see below. |
| Feature engineering + models | `model/predictor.py` | Trains 3 classifiers (win, cover, over) + 1 regressor (total points). Uses **XGBoost** if installed (it's in `requirements.txt`); falls back to scikit-learn's `HistGradientBoosting` (same gradient-boosted-tree family) if XGBoost isn't available in your environment. |
| Real API scaffolding | `data_sources.py` | Ready-to-use functions for CollegeFootballData.com and The Odds API — see below. |
| Web app | `app.py`, `templates/index.html`, `static/style.css` | Flask app serving the dashboard and a `/api/predictions` JSON endpoint. |

## Going from demo data to real data

The prototype currently trains and predicts on **synthetic** data
(`generate_sample_data.py`) so it runs standalone with no keys. To go live:

1. **Get free API keys:**
   - [CollegeFootballData.com](https://collegefootballdata.com) — CFB games,
     SP+/ELO/FPI team ratings, and historical betting lines. Free tier.
   - [The Odds API](https://the-odds-api.com) — live odds across many
     sportsbooks for both `americanfootball_nfl` and `americanfootball_ncaaf`.
     Free tier: 500 requests/month.
2. Set them as environment variables:
   ```bash
   export CFBD_API_KEY=your_key_here
   export ODDS_API_KEY=your_key_here
   ```
3. In `data_sources.py`, the functions `get_cfb_games`, `get_cfb_betting_lines`,
   `get_cfb_team_ratings`, and `get_odds` are ready to call — replace the calls
   to `pd.read_csv("data/historical_games.csv")` in `model/predictor.py` and
   `data/upcoming_games.csv` in `predict_slate()` with these live pulls.
4. For NFL, there's no single equivalent of CFBD — pair **The Odds API** for
   lines with a free historical stats source like
   [nflverse/nflfastR](https://github.com/nflverse/nflfastR-data) (open CSVs
   on GitHub, no key required) for team performance features.
5. `data_sources.py` already includes `find_line_discrepancies()`, which walks
   The Odds API's per-game bookmaker list and flags any game where sportsbooks
   disagree by more than a point on the same market — the core of the
   line-shopping / value-bet feature.

## How the discrepancy/value-bet logic works

Two independent signals, both surfaced as chips on the dashboard:

- **Books split** — the two sportsbook feeds disagree on the spread (≥1 pt)
  or total (≥2 pts) for the same game. In production with The Odds API, this
  extends naturally to *n* sportsbooks instead of 2.
- **Model value** — the model's implied point edge diverges from the market
  spread by ≥3 points, meaning the model thinks the market line is off.

Both are heuristics you'll want to tune against real outcomes over time —
treat the current thresholds as a starting point, not a finished strategy.

## Model performance (on synthetic data)

The console output when you run `python model/predictor.py` shows test-set
accuracy for each classifier and MAE for the totals regressor. On synthetic
data, these numbers are illustrative — once you swap in real historical
games and lines, retrain and re-evaluate before trusting the picks.

## Project structure

```
sports_predictor/
├── app.py                   # Flask server
├── data_sources.py          # Real API integration (CFBD + The Odds API)
├── generate_sample_data.py  # Synthetic demo dataset generator
├── requirements.txt
├── model/
│   └── predictor.py         # Feature engineering, training, inference
├── data/
│   ├── historical_games.csv
│   └── upcoming_games.csv
├── templates/
│   └── index.html
└── static/
    └── style.css
```

## Notes

- This is a prototype for learning/demo purposes, not a production betting
  system — nothing here constitutes betting advice, and past accuracy on
  synthetic data says nothing about real-world edge.
- To push this to your GitHub repo: `git init`, add a `.gitignore` for
  `model/artifacts/` and `__pycache__/`, commit, and push.
