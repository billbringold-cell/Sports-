"""
app.py — Flask web app that serves the win probability / ATS / totals
predictions and flags cross-book line discrepancies.

Run:
    python app.py
Then open http://localhost:5000
"""

import os
from flask import Flask, render_template, jsonify

from model.predictor import train_all, load_models, predict_slate, MODEL_DIR

app = Flask(__name__)


def ensure_models_trained():
    needed = ["home_win.joblib", "home_covered_a.joblib", "over_a.joblib", "actual_total.joblib"]
    if not all(os.path.exists(os.path.join(MODEL_DIR, f)) for f in needed):
        print("No trained models found — training now on sample data...")
        train_all()


@app.route("/")
def dashboard():
    ensure_models_trained()
    preds = predict_slate()
    nfl_games = preds[preds["league"] == "NFL"].to_dict(orient="records")
    cfb_games = preds[preds["league"] == "CFB"].to_dict(orient="records")
    return render_template("index.html", nfl_games=nfl_games, cfb_games=cfb_games)


@app.route("/api/predictions")
def api_predictions():
    ensure_models_trained()
    preds = predict_slate()
    return jsonify(preds.to_dict(orient="records"))


if __name__ == "__main__":
    ensure_models_trained()
    app.run(debug=True, host="0.0.0.0", port=5000)
