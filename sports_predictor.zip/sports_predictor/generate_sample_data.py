"""
generate_sample_data.py

Builds a synthetic-but-realistic historical dataset of NFL and CFB games so the
model pipeline can be trained and demoed end-to-end without live API keys.

Replace this step in production with real pulls from:
  - CollegeFootballData.com API (CFB games, team ratings, betting lines)
  - The Odds API (NFL + CFB live odds, multiple sportsbooks)
See data_sources.py for the real integration points.
"""

import numpy as np
import pandas as pd

RNG = np.random.default_rng(42)

NFL_TEAMS = [
    "Bills", "Dolphins", "Patriots", "Jets", "Ravens", "Bengals", "Browns",
    "Steelers", "Texans", "Colts", "Jaguars", "Titans", "Broncos", "Chiefs",
    "Raiders", "Chargers", "Cowboys", "Giants", "Eagles", "Commanders",
    "Bears", "Lions", "Packers", "Vikings", "Falcons", "Panthers", "Saints",
    "Buccaneers", "Cardinals", "49ers", "Seahawks", "Rams",
]

CFB_TEAMS = [
    "Alabama", "Georgia", "Ohio State", "Michigan", "Texas", "Oklahoma",
    "LSU", "Florida", "Clemson", "Notre Dame", "Oregon", "Washington",
    "Penn State", "USC", "Tennessee", "Utah", "Ole Miss", "Wisconsin",
    "Iowa", "Florida State", "Miami", "Texas A&M", "Auburn", "Baylor",
    "Kansas State", "Oklahoma State", "TCU", "North Carolina", "Louisville",
    "Missouri",
]


def _make_league(teams, league, n_games, base_rating_spread):
    """Simulate a season of games for one league with realistic rating-driven outcomes."""
    ratings = {t: RNG.normal(0, base_rating_spread) for t in teams}
    rows = []
    for i in range(n_games):
        home, away = RNG.choice(teams, size=2, replace=False)
        home_adv = 2.2  # points, standard home-field edge
        true_margin_mean = ratings[home] - ratings[away] + home_adv

        # Actual game outcome (adds game-to-game randomness / variance)
        actual_margin = RNG.normal(true_margin_mean, 13.5)
        total_points_mean = 44 if league == "NFL" else 55
        actual_total = max(20, RNG.normal(total_points_mean, 10))

        home_score = round((actual_total + actual_margin) / 2)
        away_score = round((actual_total - actual_margin) / 2)
        home_score, away_score = max(0, home_score), max(0, away_score)

        # "Market" lines: close to true expectation but with noise + occasional
        # divergence between two sportsbooks (this divergence is what the
        # discrepancy/value-bet finder is designed to catch).
        market_spread = -round((true_margin_mean + RNG.normal(0, 1.5)) * 2) / 2  # home favored = negative
        market_total = round((total_points_mean + RNG.normal(0, 3)) * 2) / 2

        book_a_spread = market_spread + RNG.choice([0, 0, 0, 0.5, -0.5, 1.0])
        book_b_spread = market_spread + RNG.choice([0, 0, 0, -0.5, 0.5, -1.0])
        book_a_total = market_total + RNG.choice([0, 0, 1, -1])
        book_b_total = market_total + RNG.choice([0, 0, -1, 1, 1.5])

        rows.append({
            "league": league,
            "week": (i % 17) + 1,
            "home_team": home,
            "away_team": away,
            "home_rating": round(ratings[home], 2),
            "away_rating": round(ratings[away], 2),
            "home_score": int(home_score),
            "away_score": int(away_score),
            "actual_margin": home_score - away_score,
            "actual_total": home_score + away_score,
            "book_a_spread": book_a_spread,   # home team spread, e.g. -6.5
            "book_b_spread": book_b_spread,
            "book_a_total": book_a_total,
            "book_b_total": book_b_total,
        })
    return pd.DataFrame(rows)


def build_dataset():
    nfl = _make_league(NFL_TEAMS, "NFL", n_games=1600, base_rating_spread=6.5)
    cfb = _make_league(CFB_TEAMS, "CFB", n_games=1600, base_rating_spread=10.5)
    df = pd.concat([nfl, cfb], ignore_index=True)

    # Labels
    df["home_win"] = (df["actual_margin"] > 0).astype(int)
    df["home_covered_a"] = (df["actual_margin"] + df["book_a_spread"] > 0).astype(int)
    df["over_a"] = (df["actual_total"] > df["book_a_total"]).astype(int)
    return df


def build_upcoming_slate(n_nfl=8, n_cfb=10):
    """A small slate of 'upcoming' games (no result yet) to generate live predictions for."""
    rows = []
    for league, teams, base in [("NFL", NFL_TEAMS, 6.5), ("CFB", CFB_TEAMS, 10.5)]:
        n = n_nfl if league == "NFL" else n_cfb
        ratings = {t: RNG.normal(0, base) for t in teams}
        for _ in range(n):
            home, away = RNG.choice(teams, size=2, replace=False)
            true_margin_mean = ratings[home] - ratings[away] + 2.2
            total_mean = 44 if league == "NFL" else 55
            market_spread = -round((true_margin_mean + RNG.normal(0, 1.5)) * 2) / 2
            market_total = round((total_mean + RNG.normal(0, 3)) * 2) / 2
            rows.append({
                "league": league,
                "home_team": home,
                "away_team": away,
                "home_rating": round(ratings[home], 2),
                "away_rating": round(ratings[away], 2),
                "book_a_spread": market_spread + RNG.choice([0, 0.5, -0.5, 1.0, -1.0, 1.5]),
                "book_b_spread": market_spread + RNG.choice([0, -0.5, 0.5, -1.0, 1.0, -1.5]),
                "book_a_total": market_total + RNG.choice([0, 1, -1, 2]),
                "book_b_total": market_total + RNG.choice([0, -1, 1, -2, 2.5]),
            })
    return pd.DataFrame(rows)


if __name__ == "__main__":
    hist = build_dataset()
    hist.to_csv("data/historical_games.csv", index=False)
    upcoming = build_upcoming_slate()
    upcoming.to_csv("data/upcoming_games.csv", index=False)
    print(f"Wrote {len(hist)} historical games and {len(upcoming)} upcoming games.")
